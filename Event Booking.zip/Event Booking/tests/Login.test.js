// tests/login.test.js
const { test } = require('@playwright/test');
const LoginPage = require('../pages/LoginPage');
const DashboardPage = require('../pages/DashboardPage');
require('dotenv').config();

test('Login with valid credentials', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const dashboardPage = new DashboardPage(page);

  await loginPage.navigateToLogin();
  await loginPage.loginWithCredentials(process.env.EMAIL, process.env.PASSWORD);
  await loginPage.isLoginSuccessful();
  await dashboardPage.assertUserIsLoggedIn();
});
