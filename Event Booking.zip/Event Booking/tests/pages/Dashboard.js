// pages/DashboardPage.js
const { expect } = require('@playwright/test');

class DashboardPage {
  constructor(page) {
    this.page = page;
    this.profileIcon = 'text=Profile'; // Adjust selector
  }

  async assertUserIsLoggedIn() {
    await expect(this.page.locator(this.profileIcon)).toBeVisible();
  }
}

module.exports = DashboardPage;
