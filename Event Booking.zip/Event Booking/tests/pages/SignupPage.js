// pages/SignupPage.js
class SignupPage {
  constructor(page) {
    this.page = page;
    this.signupLink = 'text=Sign Up';
    this.emailInput = 'input[name="email"]';
    this.passwordInput = 'input[name="password"]';
    this.confirmPasswordInput = 'input[name="confirmPassword"]'; // Adjust selector as needed
    this.signupButton = 'button[type="submit"]';
  }

  async navigate() {
    await this.page.goto('/');
    await this.page.click(this.signupLink);
  }

  async signup(email, password) {
    await this.page.fill(this.emailInput, email);
    await this.page.fill(this.passwordInput, password);
    await this.page.fill(this.confirmPasswordInput, password);
    await this.page.click(this.signupButton);
  }
}

module.exports = SignupPage;