const { test, expect } = require('@playwright/test');
const SignupPage = require('../pages/SignupPage');
const DashboardPage = require('../pages/DashboardPage');
const { newUser } = require('../utils/testData');

test('Signup with new user credentials', async ({ page }) => {
  const signupPage = new SignupPage(page);
  const dashboardPage = new DashboardPage(page);

  await signupPage.navigate();
  await signupPage.signup(newUser.email, newUser.password);

  expect(await dashboardPage.isLoggedIn()).toBeTruthy();
});
